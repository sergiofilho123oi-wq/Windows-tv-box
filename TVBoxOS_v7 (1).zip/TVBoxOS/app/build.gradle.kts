plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
 namespace="br.tvboxos"; compileSdk=34
 defaultConfig{applicationId="br.tvboxos";minSdk=29;targetSdk=29;versionCode=7;versionName="0.7"}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
 lint{abortOnError=false}
}
dependencies{implementation("androidx.core:core-ktx:1.13.1")}
