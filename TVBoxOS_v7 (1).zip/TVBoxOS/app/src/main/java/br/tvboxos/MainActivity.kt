package br.tvboxos
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
  lateinit var st: Store; lateinit var ps: MutableList<Profile>
  val h = Handler(Looper.getMainLooper())
  var applyWall: () -> Unit = {}
  var onStart: () -> Unit = {}
  var onCycle: () -> Unit = {}
  var onRefresh: () -> Unit = {}
  var topExplorer: () -> Explorer? = { null }
  fun icon(pk: String) = try { packageManager.getApplicationIcon(pk) } catch (e: Exception) { null }
  override fun dispatchKeyEvent(e: KeyEvent): Boolean {
    if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
      if (e.keyCode == KeyEvent.KEYCODE_META_LEFT || e.keyCode == KeyEvent.KEYCODE_META_RIGHT) { onStart(); return true }
      if (e.keyCode == KeyEvent.KEYCODE_TAB && e.isAltPressed) { onCycle(); return true }
    }
    if (e.action == KeyEvent.ACTION_DOWN && currentFocus !is EditText && currentFocus !is android.webkit.WebView) {
      val x = topExplorer()
      if (x != null && x.key(e)) return true
      if (e.keyCode == KeyEvent.KEYCODE_F5) { onRefresh(); return true }
    }
    return super.dispatchKeyEvent(e)
  }

  override fun onCreate(s: Bundle?) { super.onCreate(s); st = Store(this); ps = st.all(); login() }
  override fun onBackPressed() {}
  override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f)
    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN }

  fun apps(): List<Pair<String, String>> {
    val pm = packageManager; val l = mutableListOf<Pair<String, String>>()
    for (c in listOf(Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_LEANBACK_LAUNCHER))
      pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(c), 0).forEach {
        if (it.activityInfo.packageName != packageName) l.add(it.loadLabel(pm).toString() to it.activityInfo.packageName) }
    return l.distinctBy { it.second }.sortedBy { it.first.lowercase() }
  }
  fun launch(pkg: String) { (packageManager.getLaunchIntentForPackage(pkg) ?: packageManager.getLeanbackLaunchIntentForPackage(pkg))?.let { startActivity(it) } }
  fun label(pkg: String) = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }

  fun login() {
    h.removeCallbacksAndMessages(null)
    ps = st.all(); onStart = {}; onCycle = {}; onRefresh = {}; topExplorer = { null }
    val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, WALLS[0]) }
    r.addView(tv("TVBox OS", 34f)); r.addView(tv("Escolha o perfil", 16f))
    val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(30), 0, 0) }
    ps.forEach { p ->
      row.addView(Button(this).apply { text = "${p.avatar}\n${p.name}"; isAllCaps = false; textSize = 18f
        setOnClickListener { if (p.pass.isEmpty()) desktop(p) else ask("Senha de ${p.name}", "", true) { if (sha(it) == p.pass) desktop(p) else toast("Senha incorreta") } } },
        LinearLayout.LayoutParams(dp(160), dp(160)).apply { setMargins(dp(10), 0, dp(10), 0) })
    }
    r.addView(row); setContentView(r)
  }

  fun desktop(p: Profile) {
    val rootDir = st.root(p); val fg = Color.WHITE
    val root = FrameLayout(this); val wall = View(this); root.addView(wall, FrameLayout.LayoutParams(-1, -1))
    applyWall = { wall.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, WALLS[p.wall]) }; applyWall()
    val layer = FrameLayout(this); root.addView(layer, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = dp(48) })
    val icons = GridLayout(this).apply { orientation = GridLayout.VERTICAL; rowCount = 6 }; layer.addView(icons)
    val btns = LinearLayout(this)

    fun openWin(t: String, v: View) {
      lateinit var w: Win
      val b = Button(this).apply { text = t; isAllCaps = false; maxLines = 1
        setOnClickListener { if (w.visibility == View.VISIBLE && layer.indexOfChild(w) == layer.childCount - 1) w.visibility = View.GONE else { w.visibility = View.VISIBLE; w.bringToFront() } } }
      w = Win(this, t, v, p.dark) { layer.removeView(it); btns.removeView(b) }
      val n = layer.childCount
      layer.addView(w, FrameLayout.LayoutParams(dp(760), dp(430)))
      w.x = dp(40 + n * 26).toFloat(); w.y = dp(10 + n * 22).toFloat()
      btns.addView(b, LinearLayout.LayoutParams(dp(150), -1))
    }
    fun text(f: File) = openWin(f.name, Notepad(this, f, p.dark))
    mediaOpener = { f -> openWin(f.name, MediaView(this, f)) }
    pdfOpener = { f -> try { openWin(f.name, PdfView(this, f, p.dark)) } catch (e: Exception) { toast("Não foi possível abrir o PDF") } }
    fun explorer(start: File) = openWin("Explorador de Arquivos", Explorer(this, rootDir, start, p.dark, ::text))
    lateinit var refreshIcons: () -> Unit
    val settings = { openWin("Configurações", SettingsView(this, st, ps, p, ::apps, { applyWall(); refreshIcons() }, ::login)) }

    val browser = { openWin("Navegador", Browser(this, File(rootDir, "Downloads"), "https://www.google.com")) }
    val gallery = { openWin("Galeria", GalleryView(this, rootDir, p.dark)) }
    val downloads = { openWin("Gerenciador de Downloads", DownloadsView(this, File(rootDir, "Downloads"), p.dark, ::text)) }
    refreshIcons = {
      icons.removeAllViews(); icons.rowCount = 8 - 2 * p.size
      fun ic(e: String, l: String, click: () -> Unit, right: () -> Unit, d: android.graphics.drawable.Drawable? = null) {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4))
          if (d != null) addView(ImageView(this@MainActivity).apply { setImageDrawable(d) }, LinearLayout.LayoutParams(dp(40), dp(40))) else addView(tv(e, 30f)); addView(tv(l, 12f, fg).apply { gravity = Gravity.CENTER; maxLines = 2; setShadowLayer(3f, 1f, 1f, Color.BLACK) })
          setOnClickListener { click() }; onRight(right) }
        icons.addView(v, GridLayout.LayoutParams().apply { width = dp(60 + 28 * p.size); height = dp(58 + 26 * p.size) })
      }
      ic("📁", "Explorador", { explorer(rootDir) }, {})
      ic("⚙️", "Configurações", { settings() }, {})
      ic("📝", "Bloco de Notas", { ask("Nome do documento") { val f = File(File(rootDir, "Documentos"), if (it.endsWith(".txt")) it else "$it.txt"); text(f) } }, {})
      ic("🌐", "Navegador", { browser() }, {})
      ic("🖼️", "Galeria", { gallery() }, {})
      ic("⬇️", "Downloads", { downloads() }, {})
      p.favs.toList().forEach { pk -> ic("📱", label(pk), { launch(pk) }, { menu(label(pk), listOf("Abrir" to { launch(pk) }, "Remover atalho" to { p.favs.remove(pk); st.save(ps); refreshIcons() })) }, icon(pk)) }
      (File(rootDir, "Desktop").listFiles() ?: arrayOf()).sortedBy { it.name.lowercase() }.forEach { f ->
        val open = { if (f.isDirectory) explorer(f) else openFile(this, f, ::text) }
        ic(if (f.isDirectory) "📁" else "📄", f.name, open, { menu(f.name, listOf("Abrir" to open,
          "Renomear" to { ask("Novo nome", f.name) { f.renameTo(File(f.parentFile, it)); refreshIcons() } },
          "Excluir" to { f.deleteRecursively(); refreshIcons() })) })
      }
    }
    refreshIcons()
    layer.onRight { menu("Área de Trabalho", listOf(
      "Atualizar" to { refreshIcons() }, "Organizar ícones" to { refreshIcons() },
      "Exibir" to { menu("Exibir", listOf("Ícones pequenos" to { p.size = 0; st.save(ps); refreshIcons() }, "Ícones médios" to { p.size = 1; st.save(ps); refreshIcons() }, "Ícones grandes" to { p.size = 2; st.save(ps); refreshIcons() })) },
      "Nova pasta" to { ask("Nome da pasta") { File(File(rootDir, "Desktop"), it).mkdirs(); refreshIcons() } },
      "Novo documento de texto" to { ask("Nome") { File(File(rootDir, "Desktop"), if (it.endsWith(".txt")) it else "$it.txt").createNewFile(); refreshIcons() } },
      "Alterar papel de parede" to { p.wall = (p.wall + 1) % WALLS.size; st.save(ps); applyWall() },
      "Personalizar" to { settings() }, "Configurações" to { settings() })) }

    val bar = LinearLayout(this).apply { setBackgroundColor(0xE6202020.toInt()); gravity = Gravity.CENTER_VERTICAL }
    val startBtn = Button(this).apply { text = "⊞ Iniciar"; isAllCaps = false; setOnClickListener {
      val items = mutableListOf<Pair<String, () -> Unit>>("📁 Explorador de Arquivos" to { explorer(rootDir) }, "⚙️ Configurações" to { settings() })
      items.add("🌐 Navegador" to { browser() }); items.add("🖼️ Galeria" to { gallery() }); items.add("⬇️ Downloads" to { downloads() })
      items.addAll(apps().map { x -> x.first to { launch(x.second) } })
      items.add("🔒 Trocar usuário (${p.name})" to { login() })
      menu("Menu Iniciar", items) } }
    bar.addView(startBtn, LinearLayout.LayoutParams(dp(110), -1))
    val prev = applyWall; applyWall = { prev(); bar.setBackgroundColor(ACCENTS[p.accent]) }; applyWall()
    onRefresh = { refreshIcons() }
    topExplorer = { (0 until layer.childCount).map { layer.getChildAt(it) }.filterIsInstance<Win>().lastOrNull { it.visibility == View.VISIBLE }?.let { w -> w.getChildAt(1) as? Explorer } }
    onStart = { startBtn.performClick() }
    onCycle = { (0 until layer.childCount).map { layer.getChildAt(it) }.filterIsInstance<Win>().firstOrNull()?.let { it.visibility = View.VISIBLE; it.bringToFront() } }
    bar.addView(btns, LinearLayout.LayoutParams(0, -1, 1f))
    val clock = tv("", 13f).apply { gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0)
      setOnClickListener { android.app.AlertDialog.Builder(this@MainActivity).setView(CalendarView(this@MainActivity)).show() } }
    bar.addView(tv("🔊", 18f).apply { setPadding(dp(8), 0, dp(8), 0); gravity = Gravity.CENTER
      fun vol(d: Int) = (getSystemService(AUDIO_SERVICE) as android.media.AudioManager).adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, d, android.media.AudioManager.FLAG_SHOW_UI)
      setOnClickListener { vol(android.media.AudioManager.ADJUST_RAISE) }; onRight { vol(android.media.AudioManager.ADJUST_LOWER) } }, LinearLayout.LayoutParams(-2, -1))
    bar.addView(tv("📶", 18f).apply { setPadding(dp(8), 0, dp(8), 0); gravity = Gravity.CENTER
      setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) } }, LinearLayout.LayoutParams(-2, -1))
    bar.addView(clock, LinearLayout.LayoutParams(-2, -1))
    val tick = object : Runnable { override fun run() { clock.text = SimpleDateFormat("HH:mm\ndd/MM/yyyy", Locale.getDefault()).format(Date()); h.postDelayed(this, 15000) } }
    h.removeCallbacksAndMessages(null); tick.run()
    root.addView(bar, FrameLayout.LayoutParams(-1, dp(48), Gravity.BOTTOM))
    setContentView(root)
  }
}
