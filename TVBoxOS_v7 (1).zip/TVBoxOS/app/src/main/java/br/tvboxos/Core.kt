package br.tvboxos
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.View
import android.widget.*
import org.json.*
import java.io.File
import java.security.MessageDigest

val WALLS = arrayOf(
 intArrayOf(0xFF0B3D91.toInt(), 0xFF5BA8FF.toInt()), intArrayOf(0xFF1B1B2F.toInt(), 0xFF7B2FF7.toInt()),
 intArrayOf(0xFF004D40.toInt(), 0xFF69F0AE.toInt()), intArrayOf(0xFF3E2723.toInt(), 0xFFFF8A65.toInt()))

data class Profile(val id: String, var name: String, var pass: String, var wall: Int, var dark: Boolean, val favs: MutableList<String>, var avatar: String = "👤", var size: Int = 1, var accent: Int = 0)

fun sha(s: String) = if (s.isEmpty()) "" else MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

class Store(val ctx: Context) {
  private val sp = ctx.getSharedPreferences("tvbox", 0)
  fun all(): MutableList<Profile> {
    val a = JSONArray(sp.getString("profiles", "[]")); val l = mutableListOf<Profile>()
    for (i in 0 until a.length()) { val o = a.getJSONObject(i); val f = mutableListOf<String>(); val fa = o.getJSONArray("favs")
      for (j in 0 until fa.length()) f.add(fa.getString(j))
      l.add(Profile(o.getString("id"), o.getString("name"), o.getString("pass"), o.getInt("wall"), o.getBoolean("dark"), f, o.optString("avatar", "👤"), o.optInt("size", 1), o.optInt("accent", 0))) }
    if (l.isEmpty()) { l.add(Profile("p1", "Sérgio", "", 0, true, mutableListOf())); save(l) }
    return l
  }
  fun save(l: List<Profile>) {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("pass", it.pass).put("wall", it.wall).put("dark", it.dark).put("favs", JSONArray(it.favs)).put("avatar", it.avatar).put("size", it.size).put("accent", it.accent)) }
    sp.edit().putString("profiles", a.toString()).apply()
  }
  fun root(p: Profile): File {
    val r = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "profiles/${p.id}")
    listOf("Desktop", "Downloads", "Documentos", "Imagens", "Vídeos", "Música").forEach { File(r, it).mkdirs() }
    return r
  }
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
fun Context.tv(t: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = size; setTextColor(color) }
fun Context.ask(title: String, init: String = "", pw: Boolean = false, cb: (String) -> Unit) {
  val e = EditText(this).apply { setText(init); setSingleLine()
    if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
  AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("OK") { _, _ -> cb(e.text.toString()) }.setNegativeButton("Cancelar", null).show()
}
fun Context.menu(title: String, items: List<Pair<String, () -> Unit>>) {
  AlertDialog.Builder(this).setTitle(title).setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }.show()
}
fun View.onRight(f: () -> Unit) { setOnLongClickListener { f(); true }; setOnContextClickListener { f(); true } }

val ACCENTS = intArrayOf(0xE6202020.toInt(), 0xE60B3D91.toInt(), 0xE6004D40.toInt(), 0xE64A148C.toInt(), 0xE6B71C1C.toInt())
