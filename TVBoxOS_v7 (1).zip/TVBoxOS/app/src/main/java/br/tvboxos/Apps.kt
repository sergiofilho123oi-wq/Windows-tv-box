package br.tvboxos
import android.app.DownloadManager
import android.net.Uri
import android.graphics.BitmapFactory
import android.webkit.URLUtil
import android.webkit.WebView
import android.webkit.PermissionRequest
import android.Manifest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.webkit.WebViewClient
import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.webkit.MimeTypeMap
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File

fun openFile(a: Activity, f: File, openText: (File) -> Unit) {
  val ext = f.extension.lowercase()
  if (ext in listOf("mp4", "mkv", "webm", "3gp", "mp3", "m4a", "ogg", "wav", "flac", "aac")) { val m = mediaOpener; if (m != null) { m(f); return } }
  if (ext == "pdf") { val o = pdfOpener; if (o != null) { o(f); return } }
  if (ext in listOf("txt", "md", "json", "log", "csv")) { openText(f); return }
  try {
    val uri = FileProvider.getUriForFile(a, "br.tvboxos.fp", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    a.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
  } catch (e: Exception) { a.toast("Nenhum app para abrir este arquivo") }
}

class Notepad(a: Activity, val f: File, dark: Boolean) : LinearLayout(a) {
  init {
    orientation = LinearLayout.VERTICAL; val fg = if (dark) Color.WHITE else Color.BLACK
    val e = EditText(a).apply { setText(if (f.exists()) f.readText() else ""); setTextColor(fg); gravity = Gravity.TOP }
    addView(Button(a).apply { text = "Salvar"; setOnClickListener { f.writeText(e.text.toString()); a.toast("Salvo") } })
    addView(e, LayoutParams(-1, 0, 1f))
  }
}

class Explorer(val a: Activity, val root: File, start: File, dark: Boolean, val openText: (File) -> Unit) : LinearLayout(a) {
  var cur = root; var clip: List<File> = emptyList(); var cut = false
  val sel = mutableListOf<File>(); val undo = ArrayDeque<() -> Unit>()
  var shown: List<File> = emptyList(); var lastTap = 0L; var lastFile: File? = null
  val trash = File(root, ".lixeira").also { it.mkdirs() }
  val fg = if (dark) Color.WHITE else Color.BLACK
  val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; isFocusableInTouchMode = true }
  val path = a.tv("", 13f, fg)
  val search = EditText(a).apply { hint = "Pesquisar (Enter)"; setTextColor(fg); setHintTextColor(Color.GRAY); setSingleLine() }
  init {
    orientation = LinearLayout.VERTICAL
    val bar = LinearLayout(a); val bar2 = LinearLayout(a)
    fun b(l: LinearLayout, t: String, f: () -> Unit) = l.addView(Button(a).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
    b(bar, "⬆") { up() }
    b(bar, "↶") { undoLast() }
    b(bar, "Nova pasta") { a.ask("Nome") { val f = File(cur, it); f.mkdirs(); made(f) } }
    b(bar, "Novo texto") { a.ask("Nome") { val f = File(cur, if (it.endsWith(".txt")) it else "$it.txt"); f.createNewFile(); made(f) } }
    b(bar, "Colar") { paste() }
    bar.addView(search, LayoutParams(0, -2, 1f))
    search.setOnEditorActionListener { _, _, _ -> go(cur); true }
    (root.listFiles() ?: arrayOf()).filter { it.isDirectory && !it.name.startsWith(".") }.sortedBy { it.name }.forEach { d -> b(bar2, d.name) { search.setText(""); go(d) } }
    b(bar2, "🗑 Lixeira") { search.setText(""); go(trash) }
    addView(bar); addView(HorizontalScrollView(a).apply { addView(bar2) }); addView(path)
    addView(ScrollView(a).apply { addView(list) }, LayoutParams(-1, 0, 1f))
    go(start)
  }
  fun go(d: File) { cur = d; sel.clear(); render() }
  fun up() { if (cur != root) go(cur.parentFile!!) }
  fun made(f: File) { undo.addLast { f.deleteRecursively() }; go(cur) }
  fun openIt(f: File) { if (f.isDirectory) { search.setText(""); go(f) } else openFile(a, f, openText) }
  fun render() {
    path.text = "  " + cur.path.removePrefix(root.parentFile!!.path); list.removeAllViews()
    val q = search.text.toString(); val inTrash = cur == trash
    shown = if (q.isEmpty()) (cur.listFiles() ?: arrayOf()).filter { !it.name.endsWith(".origem") && (inTrash || !it.name.startsWith(".")) }.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
      else cur.walkTopDown().filter { it != cur && !it.path.startsWith(trash.path) && it.name.contains(q, true) }.take(200).toList()
    shown.forEach { f ->
      val dn = if (inTrash) f.name.substringAfter("_") else f.name
      list.addView(a.tv((if (f.isDirectory) "📁  " else "📄  ") + dn, 16f, fg).apply {
        setPadding(a.dp(10), a.dp(8), a.dp(10), a.dp(8)); if (f in sel) setBackgroundColor(0x553D8BFF)
        setOnClickListener { list.requestFocus(); val now = SystemClock.uptimeMillis()
          if (lastFile == f && now - lastTap < 450) { lastFile = null; openIt(f) } else { lastFile = f; lastTap = now; sel.clear(); sel.add(f); render() } }
        onRight {
          if (f !in sel) { sel.clear(); sel.add(f); list.post { render() } }
          val m = mutableListOf<Pair<String, () -> Unit>>("Abrir" to { openIt(f) }, "Renomear" to { rename() }, "Copiar" to { copy(false) },
            "Recortar" to { copy(true) }, "Excluir" to { del(false) }, "Excluir permanentemente" to { del(true) })
          if (inTrash) m.add(0, "Restaurar" to { restore() })
          a.menu(dn, m) }
      })
    }
  }
  fun selAll() { sel.clear(); sel.addAll(shown); render() }
  fun copy(c: Boolean) { if (sel.isNotEmpty()) { clip = sel.toList(); cut = c; a.toast(if (c) "Recortado" else "Copiado") } }
  fun rename() { val f = sel.singleOrNull() ?: return
    a.ask("Novo nome", f.name) { val n = File(f.parentFile, it); if (f.renameTo(n)) { undo.addLast { n.renameTo(f) }; go(cur) } } }
  fun paste() {
    if (clip.isEmpty()) return
    clip.forEach { c ->
      val d0 = File(cur, c.name)
      if (cut && d0.canonicalPath == c.canonicalPath) return@forEach
      if (c.isDirectory && cur.canonicalPath.startsWith(c.canonicalPath)) return@forEach
      val dest = if (d0.exists()) File(cur, "Cópia de " + c.name) else d0
      if (cut) { if (c.renameTo(dest)) undo.addLast { dest.renameTo(c) } } else { c.copyRecursively(dest, true); undo.addLast { dest.deleteRecursively() } }
    }
    if (cut) clip = emptyList(); go(cur)
  }
  fun toTrash(f: File) {
    val d = File(trash, "${System.currentTimeMillis()}_${f.name}")
    if (f.renameTo(d)) { File(trash, d.name + ".origem").writeText(f.path); undo.addLast { restoreOne(d) } }
  }
  fun restoreOne(d: File) {
    val o = File(trash, d.name + ".origem")
    val dest = if (o.exists()) File(o.readText()) else File(root, "Documentos/" + d.name.substringAfter("_"))
    dest.parentFile?.mkdirs(); d.renameTo(dest); o.delete()
  }
  fun restore() { val fs = sel.toList(); fs.forEach { restoreOne(it) }; go(cur) }
  fun del(perm: Boolean) {
    val fs = sel.toList(); if (fs.isEmpty()) return
    val permanent = perm || cur == trash
    fun doIt() { fs.forEach { f -> if (permanent) { f.deleteRecursively(); File(trash, f.name + ".origem").delete() } else toTrash(f) }; go(cur) }
    if (permanent) android.app.AlertDialog.Builder(a).setMessage("Excluir ${fs.size} item(ns) permanentemente?").setPositiveButton("Sim") { _, _ -> doIt() }.setNegativeButton("Não", null).show()
    else doIt()
  }
  fun undoLast() { val u = undo.removeLastOrNull(); if (u == null) a.toast("Nada para desfazer") else { u(); go(cur) } }
  fun key(e: KeyEvent): Boolean {
    val ctrl = e.isCtrlPressed
    when (e.keyCode) {
      KeyEvent.KEYCODE_C -> if (ctrl) copy(false) else return false
      KeyEvent.KEYCODE_X -> if (ctrl) copy(true) else return false
      KeyEvent.KEYCODE_V -> if (ctrl) paste() else return false
      KeyEvent.KEYCODE_Z -> if (ctrl) undoLast() else return false
      KeyEvent.KEYCODE_A -> if (ctrl) selAll() else return false
      KeyEvent.KEYCODE_F2 -> rename()
      KeyEvent.KEYCODE_F5 -> go(cur)
      KeyEvent.KEYCODE_FORWARD_DEL -> del(e.isShiftPressed)
      KeyEvent.KEYCODE_DEL -> up()
      else -> return false
    }
    return true
  }
}

class SettingsView(val a: Activity, val st: Store, val ps: MutableList<Profile>, val p: Profile,
    val apps: () -> List<Pair<String, String>>, val refresh: () -> Unit, val logout: () -> Unit) : ScrollView(a) {
  val fg = if (p.dark) Color.WHITE else Color.BLACK
  val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8)) }
  init { addView(box); build() }
  fun h(t: String) = box.addView(a.tv(t, 20f, 0xFF4DA3FF.toInt()).apply { setPadding(0, a.dp(14), 0, a.dp(4)) })
  fun b(t: String, f: () -> Unit) = box.addView(Button(a).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
  fun save() { st.save(ps); refresh(); build() }
  fun build() {
    box.removeAllViews()
    h("Personalização")
    b("Cor da barra de tarefas") { p.accent = (p.accent + 1) % ACCENTS.size; save() }
    b("Trocar papel de parede") { p.wall = (p.wall + 1) % WALLS.size; save() }
    b(if (p.dark) "Tema: escuro (alternar; fecha as janelas)" else "Tema: claro (alternar; fecha as janelas)") { p.dark = !p.dark; st.save(ps); (a as MainActivity).desktop(p) }
    h("Contas — atual: ${p.name}")
    b("Criar perfil") { a.ask("Nome do perfil") { ps.add(Profile("p" + System.currentTimeMillis(), it, "", 0, true, mutableListOf())); save() } }
    b("Restaurar backup (ZIP de Downloads)") {
      val r = st.root(p); val zs = (File(r, "Downloads").listFiles() ?: arrayOf()).filter { it.extension == "zip" }
      if (zs.isEmpty()) a.toast("Nenhum ZIP em Downloads") else a.menu("Restaurar qual?", zs.map { z -> z.name to {
        try { java.util.zip.ZipInputStream(z.inputStream()).use { zi -> var e = zi.nextEntry
            while (e != null) { val f = File(r, e.name)
              if (!e.isDirectory && f.canonicalPath.startsWith(r.canonicalPath)) { f.parentFile?.mkdirs(); f.outputStream().use { o -> zi.copyTo(o) } }
              e = zi.nextEntry } }
          a.toast("Backup restaurado") } catch (x: Exception) { a.toast("Falha ao restaurar") } } }) }
    b("Backup do perfil (ZIP em Downloads)") {
      try { val r = st.root(p); val out = File(r, "Downloads/backup_${p.name}.zip")
        ZipOutputStream(out.outputStream()).use { z -> r.walkTopDown().filter { it.isFile && it != out }.forEach { f ->
          z.putNextEntry(ZipEntry(f.relativeTo(r).path)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() } }
        a.toast("Backup salvo em Downloads") } catch (e: Exception) { a.toast("Falha no backup") } }
    b("Alterar avatar") { a.menu("Avatar", listOf("👤", "😀", "👩", "👨", "👵", "🎓", "🎮", "🐱", "🚀").map { e -> e to { p.avatar = e; save() } }) }
    b("Alterar nome") { a.ask("Novo nome", p.name) { p.name = it; save() } }
    b("Alterar senha (vazio = sem senha)") { a.ask("Nova senha", "", true) { p.pass = sha(it); save() } }
    b("Excluir perfil") {
      val o = ps.filter { it.id != p.id }
      if (o.isEmpty()) a.toast("Não há outro perfil") else a.menu("Excluir qual?", o.map { q -> q.name to { ps.remove(q); st.root(q).deleteRecursively(); save() } })
    }
    b("Trocar usuário") { logout() }
    h("Sistema")
    val mi = ActivityManager.MemoryInfo(); (a.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
    val sf = StatFs(Environment.getDataDirectory().path); val dm = a.resources.displayMetrics
    box.addView(a.tv("${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} · ${Build.SUPPORTED_ABIS[0]}\n" +
      "RAM: ${mi.totalMem / 1048576} MB (livre ${mi.availMem / 1048576} MB)\n" +
      "Armazenamento: livre ${"%.1f".format(sf.availableBytes / 1073741824.0)} GB de ${"%.1f".format(sf.totalBytes / 1073741824.0)} GB\n" +
      "Resolução: ${dm.widthPixels}x${dm.heightPixels}", 14f, fg))
    h("Aplicativos")
    box.addView(a.tv("Instalados: ${apps().size} · Atalhos: ${p.favs.size}", 14f, fg))
    b("Adicionar atalho") { a.menu("Adicionar", apps().map { x -> x.first to { if (x.second !in p.favs) p.favs.add(x.second); save() } }) }
    b("Remover atalho") { a.menu("Remover", p.favs.map { k -> k to { p.favs.remove(k); save() } }) }
    h("Dispositivos")
    b("Wi-Fi") { a.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
    b("Teclado") { a.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
    b("Mouse (configurações do Android)") { a.startActivity(Intent(Settings.ACTION_SETTINGS)) }
  }
}

fun download(a: Activity, dir: File, url: String, cd: String? = null, mime: String? = null) {
  try {
    dir.mkdirs(); val name = URLUtil.guessFileName(url, cd, mime)
    val r = DownloadManager.Request(Uri.parse(url)).setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED).setDestinationUri(Uri.fromFile(File(dir, name)))
    (a.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r); a.toast("Baixando $name")
  } catch (e: Exception) { a.toast("Falha no download") }
}

class Browser(val a: Activity, val dl: File, val home: String) : LinearLayout(a) {
  val tabs = mutableListOf<WebView>(); var cur: WebView? = null; var defUA: String? = null; var desktop = false
  val holder = FrameLayout(a); val tabBar = LinearLayout(a); val url = EditText(a).apply { setSingleLine() }
  val favF = File(dl.parentFile ?: dl, "favoritos.txt")
  init {
    orientation = LinearLayout.VERTICAL
    val bar = LinearLayout(a)
    fun b(t: String, f: () -> Unit) = bar.addView(Button(a).apply { text = t; setOnClickListener { f() } })
    b("◀") { cur?.let { if (it.canGoBack()) it.goBack() } }
    b("▶") { cur?.let { if (it.canGoForward()) it.goForward() } }
    b("↻") { cur?.reload() }
    b("🖥") { desktop = !desktop; tabs.forEach { ua(it) }; cur?.reload(); a.toast(if (desktop) "Modo desktop" else "Modo móvel") }
    b("★+") { val w = cur; val u = w?.url; if (w != null && u != null) { favF.appendText("${(w.title ?: u).replace("|", " ")}|$u\n"); a.toast("Favorito salvo") } }
    b("★") { val l = if (favF.exists()) favF.readLines().filter { it.contains("|") } else listOf()
      if (l.isEmpty()) a.toast("Sem favoritos") else a.menu("Favoritos", l.map { s -> s.substringBefore("|") to { go(s.substringAfter("|")) } }) }
    bar.addView(url, LayoutParams(0, -2, 1f)); b("Ir") { go(url.text.toString()) }
    url.setOnEditorActionListener { _, _, _ -> go(url.text.toString()); true }
    addView(bar); addView(HorizontalScrollView(a).apply { addView(tabBar) }); addView(holder, LayoutParams(-1, 0, 1f))
    newTab(home)
  }
  fun ua(w: WebView) {
    w.settings.userAgentString = if (desktop) "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" else (defUA ?: "")
  }
  fun go(s: String) { val t = s.trim()
    cur?.loadUrl(if (t.startsWith("http")) t else if (t.contains(".") && !t.contains(" ")) "https://$t" else "https://www.google.com/search?q=" + Uri.encode(t)) }
  fun newTab(u: String?): WebView {
    val w = WebView(a); if (defUA == null) defUA = w.settings.userAgentString
    w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true; w.settings.useWideViewPort = true; w.settings.loadWithOverviewMode = true; w.settings.setSupportMultipleWindows(true); w.settings.javaScriptCanOpenWindowsAutomatically = true; ua(w)
    w.webViewClient = object : WebViewClient() { override fun onPageFinished(v: WebView?, s: String?) { if (v == cur) url.setText(s); refreshTabs() } }
    w.webChromeClient = chrome()
    w.setDownloadListener { s, _, cd, mime, _ -> download(a, dl, s, cd, mime) }
    tabs.add(w); select(w); if (u != null) go(u); return w
  }
  fun select(w: WebView) { cur = w; holder.removeAllViews(); holder.addView(w, FrameLayout.LayoutParams(-1, -1)); url.setText(w.url ?: ""); refreshTabs() }
  fun close(w: WebView) {
    if (tabs.size == 1) return
    val i = tabs.indexOf(w); tabs.remove(w); holder.removeView(w); w.destroy()
    if (cur == w) select(tabs[maxOf(0, i - 1)]) else refreshTabs()
  }
  fun refreshTabs() {
    tabBar.removeAllViews()
    tabs.forEach { w ->
      tabBar.addView(Button(a).apply { text = (w.title ?: "Nova aba").take(14) + (if (w == cur) " ●" else ""); isAllCaps = false; setOnClickListener { select(w) }; onRight { close(w) } })
      tabBar.addView(Button(a).apply { text = "✕"; setOnClickListener { close(w) } })
    }
    tabBar.addView(Button(a).apply { text = "＋ Aba"; isAllCaps = false; setOnClickListener { newTab(home) } })
  }
  fun chrome() = object : WebChromeClient() {
    override fun onCreateWindow(v: WebView?, d: Boolean, g: Boolean, m: android.os.Message?): Boolean {
      if (m == null) return false
      val t = m.obj as? WebView.WebViewTransport ?: return false
      t.webView = newTab(null); m.sendToTarget(); return true
    }
    override fun onReceivedTitle(v: WebView?, t: String?) { refreshTabs() }
    override fun onPermissionRequest(r: PermissionRequest?) {
      a.requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
      if (r != null) r.grant(r.resources)
    }
    override fun onShowFileChooser(w: WebView?, cb: ValueCallback<Array<Uri>>?, p: WebChromeClient.FileChooserParams?): Boolean {
      val base = (dl.parentFile ?: dl)
      val fs = base.walkTopDown().filter { it.isFile }.take(300).toList()
      if (fs.isEmpty()) { a.toast("Nenhum arquivo no perfil para enviar"); cb?.onReceiveValue(null); return true }
      android.app.AlertDialog.Builder(a).setTitle("Escolha o arquivo para enviar")
        .setItems(fs.map { it.path.removePrefix(base.path) }.toTypedArray()) { _, i -> cb?.onReceiveValue(arrayOf(Uri.fromFile(fs[i]))) }
        .setOnCancelListener { cb?.onReceiveValue(null) }.show()
      return true
    }
  }
}

class GalleryView(val a: Activity, val root: File, dark: Boolean) : LinearLayout(a) {
  val fg = if (dark) Color.WHITE else Color.BLACK
  val grid = GridLayout(a).apply { columnCount = 4 }
  val sc = ScrollView(a).apply { addView(grid) }
  init { orientation = LinearLayout.VERTICAL; show() }
  fun decode(f: File, max: Int): android.graphics.Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o)
    var s = 1; while (o.outWidth / (s * 2) >= max) s *= 2
    val o2 = BitmapFactory.Options(); o2.inSampleSize = s
    return BitmapFactory.decodeFile(f.path, o2)
  }
  fun show() {
    removeAllViews(); grid.removeAllViews(); addView(sc, LayoutParams(-1, -1))
    val imgs = root.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "mp4", "mkv", "webm", "3gp") }.take(40).toList()
    if (imgs.isEmpty()) grid.addView(a.tv("Nenhuma imagem. Coloque fotos na pasta Imagens.", 14f, fg))
    imgs.forEach { f -> grid.addView(ImageView(a).apply { val vid = f.extension.lowercase() in listOf("mp4", "mkv", "webm", "3gp")
        setImageBitmap(if (vid) try { android.media.ThumbnailUtils.createVideoThumbnail(f, android.util.Size(200, 150), null) } catch (e: Exception) { null } else decode(f, 200))
        scaleType = ImageView.ScaleType.CENTER_CROP; setOnClickListener { if (vid) openFile(a, f) { } else view(f) } },
      GridLayout.LayoutParams().apply { width = a.dp(130); height = a.dp(100); setMargins(4, 4, 4, 4) }) }
  }
  fun view(f: File) {
    removeAllViews()
    addView(Button(a).apply { text = "◀ Voltar"; setOnClickListener { show() } })
    addView(ImageView(a).apply { setImageBitmap(decode(f, 1200)); scaleType = ImageView.ScaleType.FIT_CENTER }, LayoutParams(-1, 0, 1f))
  }
}

class DownloadsView(val a: Activity, val dir: File, dark: Boolean, val openText: (File) -> Unit) : LinearLayout(a) {
  val fg = if (dark) Color.WHITE else Color.BLACK
  val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
  init {
    orientation = LinearLayout.VERTICAL
    val url = EditText(a).apply { hint = "Cole o link para baixar"; setSingleLine(); setTextColor(fg); setHintTextColor(Color.GRAY) }
    val bar = LinearLayout(a); bar.addView(url, LayoutParams(0, -2, 1f))
    bar.addView(Button(a).apply { text = "Baixar"; setOnClickListener { download(a, dir, url.text.toString().trim()); url.setText("") } })
    bar.addView(Button(a).apply { text = "Atualizar"; setOnClickListener { reload() } })
    addView(bar); addView(ScrollView(a).apply { addView(list) }, LayoutParams(-1, 0, 1f)); reload()
  }
  fun reload() {
    list.removeAllViews()
    (dir.listFiles() ?: arrayOf()).sortedByDescending { it.lastModified() }.forEach { f ->
      list.addView(a.tv("⬇  ${f.name}  (${f.length() / 1024} KB)", 15f, fg).apply {
        setPadding(a.dp(10), a.dp(8), a.dp(10), a.dp(8)); setOnClickListener { openFile(a, f, openText) }
        onRight { a.menu(f.name, listOf<Pair<String, () -> Unit>>("Abrir" to { openFile(a, f, openText) }, "Excluir" to { f.deleteRecursively(); reload() })) } })
    }
  }
}

var pdfOpener: ((File) -> Unit)? = null

class PdfView(val a: Activity, f: File, dark: Boolean) : LinearLayout(a) {
  val fg = if (dark) Color.WHITE else Color.BLACK
  val r = PdfRenderer(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY))
  var i = 0; var zoom = 1100
  val img = ImageView(a).apply { adjustViewBounds = true }
  val lbl = a.tv("", 14f, fg)
  init {
    orientation = LinearLayout.VERTICAL
    val bar = LinearLayout(a); bar.gravity = Gravity.CENTER_VERTICAL
    bar.addView(Button(a).apply { text = "◀"; setOnClickListener { if (i > 0) { i--; show() } } })
    bar.addView(Button(a).apply { text = "▶"; setOnClickListener { if (i < r.pageCount - 1) { i++; show() } } })
    bar.addView(Button(a).apply { text = "−"; setOnClickListener { if (zoom > 700) { zoom -= 300; show() } } })
    bar.addView(Button(a).apply { text = "+"; setOnClickListener { if (zoom < 1700) { zoom += 300; show() } } })
    bar.addView(lbl)
    addView(bar); addView(ScrollView(a).apply { addView(img, FrameLayout.LayoutParams(-1, -2)) }, LayoutParams(-1, 0, 1f)); show()
  }
  fun show() {
    val p = r.openPage(i); val w = zoom; val h = w * p.height / p.width
    val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); bm.eraseColor(Color.WHITE)
    p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); p.close()
    img.setImageBitmap(bm); lbl.text = "  ${i + 1} / ${r.pageCount}"
  }
}

var mediaOpener: ((File) -> Unit)? = null

class MediaView(a: Activity, f: File) : LinearLayout(a) {
  val v = VideoView(a)
  init {
    setBackgroundColor(Color.BLACK)
    v.setMediaController(MediaController(a).also { it.setAnchorView(v) })
    v.setVideoURI(Uri.fromFile(f)); v.setOnPreparedListener { it.start() }
    addView(v, LayoutParams(-1, -1))
  }
  override fun onDetachedFromWindow() { v.stopPlayback(); super.onDetachedFromWindow() }
}
