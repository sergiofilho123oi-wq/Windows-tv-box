package br.tvboxos
import android.app.Activity
import android.graphics.Color
import android.view.*
import android.widget.*

class Win(val a: Activity, val title: String, content: View, dark: Boolean, val onClose: (Win) -> Unit) : LinearLayout(a) {
  var maxed = false; var rw = 0; var rh = 0; var rx = 0f; var ry = 0f; var dx = 0f; var dy = 0f; var last = 0L
  init {
    orientation = LinearLayout.VERTICAL; isClickable = true; elevation = a.dp(8).toFloat()
    setBackgroundColor(if (dark) 0xFF202020.toInt() else 0xFFF3F3F3.toInt())
    val fg = if (dark) Color.WHITE else Color.BLACK
    val bar = LinearLayout(a).apply { setBackgroundColor(if (dark) 0xFF2D2D2D.toInt() else 0xFFE5E5E5.toInt()); gravity = Gravity.CENTER_VERTICAL }
    bar.addView(a.tv("  $title", 14f, fg).apply { gravity = Gravity.CENTER_VERTICAL; maxLines = 1 }, LinearLayout.LayoutParams(0, a.dp(34), 1f))
    fun cb(t: String, f: () -> Unit) = bar.addView(a.tv(t, 16f, fg).apply { gravity = Gravity.CENTER; setOnClickListener { f() } }, LinearLayout.LayoutParams(a.dp(44), a.dp(34)))
    cb("—") { visibility = View.GONE }
    cb("▢") { toggleMax() }
    cb("✕") { onClose(this) }
    bar.setOnTouchListener { _, e ->
      if (e.action == MotionEvent.ACTION_DOWN) { bringToFront(); dx = e.rawX - x; dy = e.rawY - y; if (e.eventTime - last < 350) toggleMax(); last = e.eventTime }
      else if (e.action == MotionEvent.ACTION_MOVE && !maxed) { x = e.rawX - dx; y = e.rawY - dy }
      true }
    addView(bar, LinearLayout.LayoutParams(-1, a.dp(34)))
    addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
    addView(a.tv("◢ ", 14f, fg).apply { gravity = Gravity.END; setOnTouchListener { _, e ->
      if (e.action == MotionEvent.ACTION_DOWN) { dx = e.rawX - this@Win.width; dy = e.rawY - this@Win.height }
      else if (e.action == MotionEvent.ACTION_MOVE && !maxed) { val lp = this@Win.layoutParams
        lp.width = maxOf(a.dp(320), (e.rawX - dx).toInt()); lp.height = maxOf(a.dp(220), (e.rawY - dy).toInt()); this@Win.layoutParams = lp }
      true } }, LinearLayout.LayoutParams(-1, a.dp(18)))
  }
  fun toggleMax() {
    val lp = layoutParams as FrameLayout.LayoutParams
    if (!maxed) { rw = lp.width; rh = lp.height; rx = x; ry = y; lp.width = -1; lp.height = -1; x = 0f; y = 0f }
    else { lp.width = rw; lp.height = rh; x = rx; y = ry }
    maxed = !maxed; layoutParams = lp
  }
}
