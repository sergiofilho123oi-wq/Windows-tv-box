# TVBox OS — Continuar projeto (v0.7)
## Compilar (GitHub)
1. Envie TODOS os arquivos do ZIP (inclusive `.github`) para um repositório.
2. Aba **Actions** → "Build APK" (roda sozinho ou via "Run workflow").
3. Baixe o artefato **TVBoxOS-debug-apk**, instale na TV Box e defina como launcher (Home).
> As versões 0.1 e 0.2 ainda NÃO foram compiladas por quem as escreveu. Se o Actions falhar, cole o log numa nova conversa junto com este ZIP.
## Concluído
- v0.1: perfis com senha, desktop, janelas, barra de tarefas, Menu Iniciar, Explorador real, Bloco de Notas, Configurações, botão direito.
- v0.2: **Navegador** (WebView, downloads vão para a pasta Downloads do perfil), **Galeria**, **Gerenciador de Downloads**, **avatar** do perfil, **ícones reais** dos apps, menu **Exibir** (ícones pequenos/médios/grandes), **redimensionar janelas** (canto ◢), atalhos: tecla **Windows** = Menu Iniciar, **Alt+Tab** = alternar janelas.
- v0.3: **envio de arquivos no navegador** (seletor com os arquivos do perfil, para provas online), **favoritos** (★+ salva, ★ lista), **leitor de PDF interno** (páginas ◀ ▶), **cor da barra de tarefas** (Configurações).
- v0.4: **player de vídeo/música** (mp4, mkv, mp3… abre ao clicar no arquivo), **zoom no PDF** (− / +), **modo desktop** no navegador (🖥, ajuda em provas), **ícone do app**, **duplo clique na barra da janela = maximizar/restaurar**. Para "abas": abra outro Navegador (cada um é uma janela na barra de tarefas).
- v0.5: **abas reais** no navegador (＋ Aba, ✕ fecha, botão direito fecha), **câmera/microfone** em provas (pede permissão do Android), **backup do perfil** em ZIP (Configurações → Contas), bandeja na barra: **volume 🔊** (clique sobe, botão direito desce) e **Wi-Fi 📶**.
- v0.6: links `target=_blank` abrem em **nova aba**; **restaurar backup** ZIP; **miniaturas de vídeo** na Galeria (clique toca); **tema** claro/escuro aplicado na hora (recria a área de trabalho e fecha as janelas).
- v0.7: **atalhos do Explorador** (janela do Explorador ativa, foco fora de campo de texto): Ctrl+C copiar, Ctrl+X recortar, Ctrl+V colar, Ctrl+Z desfazer (renomear, criar, colar, mover, excluir), Ctrl+A selecionar tudo, F2 renomear, F5 atualizar (também na área de trabalho), Delete → **Lixeira**, Shift+Delete exclui de vez, Backspace sobe uma pasta. **Lixeira** (botão 🗑, menu Restaurar). Clique seleciona; duplo clique abre.
## Falta
- Tema aplicado em janelas já abertas; arrastar ícones; 
- Atalhos (Ctrl+C etc.) para arquivos da área de trabalho (hoje só no Explorador); seleção múltipla com Ctrl+clique.
- Arrastar ícones na área de trabalho.
- Vídeo/música na Galeria (miniaturas).
- Pastas privadas com criptografia; teste real no hardware (Mali-450: ver desempenho).
